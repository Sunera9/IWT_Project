<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" type="text/css" href="../Styles/men.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>

<body>
  <?php
    include_once '../PHP/Header.php'
  ?>


<center>
  <div class="head">
    <h1>MEN'S FASHION</h1>
  </div>
</center>

<div class="row1">
<h2>MEN'S HAIRCUTS</h2>
</div>

<table style="width:100%">

  <tr>
    <td><img src="https://i.pinimg.com/originals/40/cb/bd/40cbbd624b1784b4d09a461a60ea2cc7.jpg" alt="Snow" id="p1" class="pic">
    <br>
     Pompadour</td>


    <td><img src="https://www.menshairstyletrends.com/wp-content/uploads/2021/05/Slicked-back-hair-fade-blonde-peteyrock_thebarber-1024x1024.jpg" alt="Snow" id="p2" class="pic">
    <br>Slicked Back</td>


    <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmZAHKacgLHxEqTA4OWAm9BorAJRd4MuAZ0XX4Ucjh55RdWrWTS1VuzfcT4jJHYpwUHaE&usqp=CAU" alt="Snow" id="p3" class="pic">
    <br>Blowout</td>

    <td><img src="https://i.pinimg.com/236x/bf/87/f2/bf87f22ad28fa2aff111e50dc53f332f.jpg" alt="Snow" id="p4" class="pic">
    <br>Quiff</td>
  </tr>
  </table>

  <br>

  <br>

  <div class="row1">
  <h2>MEN'S BEARD STYLES</h2>
</div>


  <table style="width:100%;">
   <tr>
    <td><img src="https://img.mensxp.com/media/content/2019/Jul/beard-styles-to-try-out-in-2019-500-2-1563514708.jpg" alt="Snow" id="p5" class="pic">
    <br>TRIANGLE</td>


    <td><img src="https://i.pinimg.com/originals/c5/30/59/c5305991d1622b0a873f29debda1ac1d.jpg" alt="Snow" id="p6" class="pic">
    <br>SQUARE</td>



    <td><img src="../img/1.jpg" alt="Snow" id="p7" class="pic">
    <br>DIAMOND</td>
  </tr>

  </table>


  <?php
    include_once '../PHP/Footer.php'
  ?>
</body>
</html>
