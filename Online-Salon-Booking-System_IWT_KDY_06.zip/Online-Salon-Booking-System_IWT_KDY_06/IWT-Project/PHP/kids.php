<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="../Styles/kid.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
  <?php
    include_once '../PHP/Header.php'
  ?>

<center>
  <div class="head">
    <h1>KID'S FASHION</h1>
  </div>
</center>

<div class="row1">
  <h2>KID'S HAIRCUTS</h2>
</div>

<table  style="width:100%">

  <tr>
    <td><img src="https://i.pinimg.com/736x/00/c0/cf/00c0cff2396351bfa85b1cad3bfcf590.jpg" id="p1">
    <br>
     Comb Over Bob Cut</td>


    <td><img src="https://i2.wp.com/therighthairstyles.com/wp-content/uploads/2013/12/11-sliced-shag-with-bronde-highlights.jpg?w=500&ssl=1" alt="Snow" id="p2">
    <br>Shaggy Lob Cut</td>


    <td><img src="https://haircutinspiration.com/wp-content/uploads/Fine-Fade-with-Shaved-Line.jpg" alt="Snow" id="p3">
    <br>Mid Taper Fade</td>

    <td><img src="https://www.menshairstylesnow.com/wp-content/uploads/2017/05/Haircuts-For-Boys-High-Fade-with-Hard-Side-Part.jpg" alt="Snow" id="p4">
    <br>High Fade with Hard Side Part.</td>
  </tr>
  </table>

  <br>

  <br>


</table>


<?php
  include_once '../PHP/Footer.php'
?>
</body>
</html>
