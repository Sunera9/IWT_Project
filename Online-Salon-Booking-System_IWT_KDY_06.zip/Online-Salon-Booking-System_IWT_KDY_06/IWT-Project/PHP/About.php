<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="../Styles/styleAbout.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>
  <?php
    include_once '../PHP/Header.php'
  ?>
    <div class="about-section">
        <div class="inner-container">
            <h1>About Us</h1>
            <p class="text">
              We are Salon Infinite...We do Hair Styles. Hair Color, And many things.</p>
              <p class="text">
              The Importance of being well-groomed & maintaining a good personal hygiene is a necessity to maintain a balance for personal, social, health, psychological or simply as a way of life. Today both men & women has many responsibilities, from caring for their family to meeting deadlines at work. And every person needs a place to escape. Naturals is that place to detox, rejuvenate and relax! Look good, Feel good!
            </p>
            <div class="skills">
                <span>Hair Styles</span>
                <span>Bridle</span>
                <span>Kids</span>
            </div>
        </div>
    </div>
    <?php
      include_once '../PHP/Footer.php'
    ?>
</body>
</html>
