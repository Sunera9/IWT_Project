<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" type="text/css" href="../Styles/women.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

</head>
<body>

  <?php
    include_once '../PHP/Header.php'
  ?>

<center>
  <div class="head">
<h1>WOMEN'S FASHION</h1>
 </div>
</center>

<br><br><br>

<div class=row1>
<h2>WOMEN'S HAIRCUTS</h2>
</div>

<table style="width:100%">

  <tr>
    <td><img src="https://i.pinimg.com/736x/72/ce/23/72ce23b4471ad11a86296a4ee3b2196e.jpg" alt="Snow" id="p1">
    <br>
     The Mullet</td>


    <td><img src="https://stylesatlife.com/wp-content/uploads/2019/02/Bob-Haircuts-39.jpg" alt="Snow" id="p2">
    <br>The Bob</td>


    <td><img src="https://i2.wp.com/www.hadviser.com/wp-content/uploads/2021/04/3-messy-curtain-bangs-CR98xqhB9W2.jpg?resize=1016%2C1166&ssl=1" alt="Snow" id="p3">
    <br>Curtain Bangs</td>

    <td><img src="https://stylesatlife.com/wp-content/uploads/2019/12/Shaggy-haircuts7.jpg.webp" alt="Snow" id="p4">
    <br>The Shag</td>
  </tr>
  </table>

  <br>

  <br>

  <div class=row1>
  <h2>WOMEN'S EYEBROW STYLES</h2>
  <br>

</div>


  <table style="width:100%">
   <tr>
    <td><img src="https://i.pinimg.com/originals/9e/00/43/9e0043571250538b0ec7e197bd1c4b65.jpg" alt="Snow" id="p5">
    <br>Fluffy brows</td>


    <td><img src="https://static-bebeautiful-in.unileverservices.com/trending-bleached-eyebrows-beauty_2.jpg" alt="Snow" id="p6">
    <br>Bleached brow</td>



    <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvmSR7UMZcBNtsBf94YXcvVTUBPOg_EqnOYFc9sjYyChSJkdd7HCJ2MAkIjjlggs8rbN4&usqp=CAU" alt="Snow" id="p7">
    <br>Straight brow</td>



    <td><img src="https://cdn.shopify.com/s/files/1/0257/9519/9064/products/ScreenShot2021-01-05at6.41.50PM_2000x2000.png?v=1613710406" alt="Snow" id="p8">
    <br>Brow lamination</td>
  </tr>

  </table>
  <br>

  <br>

  <div class=row1>
  <h2>WOMEN'S SKIN CARE</h2>
</div>


  <table style="width:100%">
   <tr>
    <td><img src="https://femina.wwmindia.com/thumb/content/2021/aug/glow-thumb1628922998.jpg?width=1200&height=900" alt="Snow" id="p9">
    <br>Facepack</td>


    <td><img src="https://www.swagmee.com/media/wysiwyg/blog/revitalizing-face-clean-up.jpg" alt="Snow" id="p10">
    <br>Face Cleanup</td>





  </table>



  <?php
    include_once '../PHP/Footer.php'
  ?>
</body>
</html>
